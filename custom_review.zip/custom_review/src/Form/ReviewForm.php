<?php

namespace Drupal\custom_review\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Drupal\commerce_order\Entity\Order;
use Drupal\user\Entity\User;

class ReviewForm extends FormBase{

     /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'review_form';
    }

    public function buildForm(array $form, FormStateInterface $form_state, $order_id = NULL){

        if ($order_id) {

            $connection = Database::getConnection();
            $exists = $connection->select('vendor_reviews', 'vr')
                ->fields('vr', ['order_id'])
                ->condition('order_id', $order_id)
                ->execute()
                ->fetchField();
            if(!$exists){

                $order_state = $vendor_uid = $vendor_previous_rating = '';            
                // Load the order entity.
                $order = Order::load($order_id);
                if ($order) {

                    $order_state = $order->get('state')->value ?? '';
                    // Get the vendor UID from the order.
                    $vendor_uid = $order->get('field_vendor_uid')->value ?? '';

                    // Load the user entity for the vendor.
                    $vendor_user = User::load($vendor_uid);

                    if ($vendor_user) {

                        $vendor_previous_rating = $vendor_user->get('field_rating')->getValue();
                        if($vendor_previous_rating != NULL){
                            $vendor_previous_rating_count = $vendor_previous_rating[0]['value'];
                        }else{
                            $vendor_previous_rating_count = 0;
                        }
                        $address_field = $vendor_user->get('field_address')->getValue();
                        $vendor_first_name = $address_field[0]['given_name'] ?? '';
                        $vendor_last_name = $address_field[0]['family_name'] ?? '';
                        
                        $vendor_detail_markup = $this->t('
                            <div class="vendor-details">
                                <p>Please rate your experience with our vendor <span>@name</span>. 
                                Your input is valuable in helping us better understand needs and tailor our service accordingly.</p>
                            </div>
                        ', [
                            '@name' => $vendor_first_name." ".$vendor_last_name,
                        ]);
                        
                    } else {
                        \Drupal::messenger()->addError($this->t('Vendor not found.'));
                        return [];
                    }

                    $form_heading_markup = '<div class="form-header-wrapper"><h2>Submit a Review</h2></div>';

                    if($order_state == 'completed'){

                        $form['order_id'] = [
                            '#type' => 'hidden',
                            '#value' => $order_id,
                        ];
                        $form['vendor_id'] = [
                            '#type' => 'hidden',
                            '#value' => $vendor_uid,
                        ];
                        $form['vendor_previous_rating'] = [
                            '#type' => 'hidden',
                            '#value' => $vendor_previous_rating_count,
                        ];
                        $form['form_header'] = [
                            '#markup' => $form_heading_markup,
                        ];
                        $form['vendor_display'] = [
                            '#markup' => $vendor_detail_markup,
                        ];
                        $form['rating'] = [
                            '#type' => 'radios',
                            '#options' => [
                                1 => '&#9733;',
                                2 => '&#9733;',
                                3 => '&#9733;',
                                4 => '&#9733;',
                                5 => '&#9733;',
                            ],
                            '#required' => TRUE,
                            '#attributes' => ['class' => ['star-input']],
                        ];
                        $form['review'] = [
                            '#type' => 'textarea',
                            '#attributes' => [
                                'placeholder' => $this->t('Add a comment...'),
                            ],
                        ];
                        $form['submit'] = [
                            '#type' => 'submit',
                            '#value' => $this->t('Submit Review'),
                        ];
        
                    }elseif($order_state == 'service'){
                        $form['order_incomplete'] = [
                            '#type' => 'markup',
                            '#markup' => '<div class="alert alert-warning" role="alert">Your service has not been completed yet!</div>',
                        ];
                    }elseif($order_state == 'cancel'){
                        $form['order_cancelled'] = [
                            '#type' => 'markup',
                            '#markup' => '<div class="alert alert-danger" role="alert">Your service has been cancelled</div>',
                        ];
                    }

                } else {
                    \Drupal::messenger()->addError($this->t('Order not found.'));
                    return [];
                }
            }else{
                $form['review_exist'] = [
                    '#type' => 'markup',
                    '#markup' => '<div class="alert alert-success" role="alert"><h2>Already Submitted</h2><p>Thank you for your time and consideration!</p><hr><p>Team Acediva</p></div>',
                ];
            }

        } else {
            \Drupal::messenger()->addError($this->t('Invalid order ID.'));
            return [];
        }

        return $form;
        
    }

    public function validateForm(array &$form, FormStateInterface $form_state){
        $values = $form_state->getValues();

        // Check for duplicate entry based on order_id.
        $connection = Database::getConnection();
        $exists = $connection->select('vendor_reviews', 'vr')
            ->fields('vr', ['order_id'])
            ->condition('order_id', $values['order_id'])
            ->execute()
            ->fetchField();
    
        if ($exists) {
            $form_state->setErrorByName('order_id', $this->t('A review for this order has already been submitted.'));
        }
    }

    public function submitForm(array &$form, FormStateInterface $form_state){

        $values = $form_state->getValues();

        // Insert the review into the database.
        $connection = Database::getConnection();
        $connection->insert('vendor_reviews')
            ->fields([
                'order_id' => $values['order_id'],
                'vendor_id' => $values['vendor_id'],
                'rating' => $values['rating'],
                'review' => $values['review'],
            ])
            ->execute();

        // Update the vendor user's rating.

        $vendor_user = User::load($values['vendor_id']);
        
        if ($vendor_user) {
        
            $existing_rating = $vendor_user->get('field_rating')->getValue();
            $new_rating = $values['rating'];
    
            // If there's an existing rating, calculate the average.
            if (!empty($existing_rating)) {
                $current_average = $existing_rating[0]['value'];
                $new_average = ($current_average + $new_rating) / 2;
                $vendor_user->set('field_rating', $new_average);
            } else {
                // If no existing rating, just set the new rating.
                $vendor_user->set('field_rating', $new_rating);
            }
    
            // Save the vendor user entity.
            $vendor_user->save();
        } else {
            \Drupal::messenger()->addError($this->t('Failed to load vendor user for updating rating.'));
        }

        // Redirect to the thank you page.
        $form_state->setRedirect('custom_review.review_submitted');
    }

}