<?php

    namespace Drupal\custom_controller\Form;

    use Drupal\Core\Form\FormBase;
    use Drupal\Core\Form\FormStateInterface;
    use Drupal\user\Entity\User;
    use Drupal\file\Entity\File;
    use Drupal\Core\Url;

    class VendordashboardForm extends FormBase {
        /**
         * {@inheritdoc}
         */
        public function getFormId(){
            return 'vendor_dashboard_form';
        }

        /**
         * {@inheritdoc}
         */
        public function buildForm(array $form, FormStateInterface $form_state){

            $current_user_id = \Drupal::currentUser()->id();
            $user = User::load($current_user_id);

            if (empty($current_user_id)){
                // Get the redirect path.
                $redirect_path = '/user/login'; // Replace with the desired redirect path.

                $url = \Drupal\Core\Url::fromUserInput($redirect_path);
                $response = new \Symfony\Component\HttpFoundation\RedirectResponse($url->toString());
                $response->send();
                exit();
            }

            $address_field = $user->get('field_address')->getValue();
            $given_name = $family_name = '';

            if (!empty($address_field)) {
                $address_data = $address_field[0]; // Assuming you are interested in the first item.
              
                $given_name = $address_data['given_name'];
                $family_name = $address_data['family_name'];
            }

            $pictureUrl = '/themes/custom/acediva/images/default-user-icon.png';
            $pictureEntity = $user->get('user_picture')->entity;
            if ($pictureEntity){
                $pictureUrl = \Drupal::service('file_url_generator')->generateAbsoluteString($pictureEntity->getFileUri());
            }
            $form['current_logo'] = [
                '#type' => 'markup',
                '#markup' => '<div class="profile-img-name"><div class="profile-img"><img class="current-logo" alt="" src="' . $pictureUrl . '" /></div><div class="profile-name">Hello! <br>' . $given_name.' '.$family_name . '</div><a class="logout-btn" href="/user/logout">Logout</a></div>',
            ];

            $form['button_container'] = [
                '#type' => 'markup',
                '#prefix' => '<div class="profile-link">',
                '#suffix' => '</div>',
            ];

            // Add the 'Your Orders' button.
            $form['button_container']['order_button'] = [
                '#type' => 'link',
                '#title' => $this->t('All Service Requests'),
                '#url' => \Drupal\Core\Url::fromUserInput('/all-service-requests'),
            ];
              
            // Add the 'View/Edit Profile' button.
            $form['button_container']['profile_button'] = [
                '#type' => 'link',
                '#title' => $this->t('View/Edit Profile'),
                '#url' => \Drupal\Core\Url::fromUserInput('/user/profile'),
            ];
              
            return $form;
        }

        public function submitForm(array &$form, FormStateInterface $form_state){}
    }