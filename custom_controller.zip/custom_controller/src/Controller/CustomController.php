<?php

namespace Drupal\custom_controller\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\taxonomy\Entity\Vocabulary;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Controller for the custom controller.
 */
class CustomController extends ControllerBase {

  /**
   * Retrieves the main category.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   The JSON response.
   */
  public function mainCategory() {
    $vocabulary = Vocabulary::load('main_category');
    $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vocabulary->id());

    $term_list = [];
    foreach ($terms as $term) {
      $term_list[] = [
        'tid' => $term->tid,
        'name' => $term->name,
      ];
    }

    $response = [
      'data' => $term_list,
      'status' => 200,
      'messageCode' => 'SUCCESS',
    ];

    return new JsonResponse($response);
  }

  /**
   * Retrieves the main category.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   The JSON response.
   */
  public function subCategory() {
    $vocabulary = Vocabulary::load('sub_category');
    $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vocabulary->id());

    $term_list = [];
    foreach ($terms as $term) {
      $term_list[] = [
        'tid' => $term->tid,
        'name' => $term->name,
      ];
    }

    $response = [
      'data' => $term_list,
      'status' => 200,
      'messageCode' => 'SUCCESS',
    ];

    return new JsonResponse($response);
  }

  /**
   * Retrieves the service listing.
   *
   * @param string|null $main_category_id
   *   The main category ID.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   The JSON response.
   */
  public function serviceListing($main_category_id = NULL) {
    $query = \Drupal::entityQuery('node')
      ->condition('type', 'service_listing')
      ->sort('created', 'DESC')
      ->accessCheck(FALSE);

    if ($main_category_id) {
      $query->condition('field_main_category', $main_category_id);
    }

    $nodeIds = $query->execute();
    $nodes = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($nodeIds);

    $node_list = [];
    foreach ($nodes as $node) {
      $title = $node->getTitle();
      $image_url = '';
      $launched = 'False';
      $main_category = '';
      $main_category_id = NULL;

      if ($node->hasField('field_image') && !$node->get('field_image')->isEmpty()) {
        $image_entity = $node->get('field_image')->entity;
        if ($image_entity) {
          $image_url = $image_entity->getFileUri();
        }
      }

      if ($node->hasField('field_launched') && !$node->get('field_launched')->isEmpty()) {
        $launched = $node->get('field_launched')->value ? 'True' : 'False';
      }

      if ($node->hasField('field_main_category') && !$node->get('field_main_category')->isEmpty()) {
        // Load the referenced term entity.
        $term_entity = $node->get('field_main_category')->entity;
        if ($term_entity) {
          // Get the name of the term.
          $main_category = $term_entity->label();
          // Get the entity ID of the term.
          $main_category_id = $term_entity->id();
        }
      }

      $node_list[] = [
        'title' => $title,
        'field_image' => $image_url,
        'field_launched' => $launched,
        'field_main_category' => $main_category,
        'field_main_category_id' => $main_category_id,
      ];
    }

    $response = [
      'data' => $node_list,
      'status' => 200,
      'messageCode' => 'SUCCESS',
    ];

    return new JsonResponse($response);
  }

  /**
   * Returns service details.
   *
   * @param int $main_category_id
   *   The main category ID.
   * @param int $sub_category_id
   *   The sub category ID.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   The JSON response containing service details.
   */
  public function serviceDetails($main_category_id = NULL, $sub_category_id = NULL) {
    $response_data = [
      'data' => [],
      'status' => 200,
      'messageCode' => 'SUCCESS',
    ];

    $query = \Drupal::entityQuery('node')
      ->condition('type', 'services')
      ->condition('status', 1)
      ->accessCheck(FALSE);

    if ($main_category_id !== NULL) {
      $query->condition('field_main_category', $main_category_id);
    }

    if ($sub_category_id !== NULL) {
      $query->condition('field_sub_category', $sub_category_id);
    }

    $nids = $query->execute();

    // Load nodes based on the query results.
    if (!empty($nids)) {
      $nodes = Node::loadMultiple($nids);

      foreach ($nodes as $node) {
        $response_data['data'][] = [
          'title' => $node->label(),
          'field_main_category_id' => $node->get('field_main_category')->target_id,
          'field_main_category' => $node->get('field_main_category')->entity->label(),
          'field_sub_category_id' => $node->hasField('field_sub_category') ? $node->get('field_sub_category')->target_id : NULL,
          'field_sub_category' => $node->hasField('field_sub_category') ? $node->get('field_sub_category')->entity->label() : NULL,
          'field_launched' => $node->get('field_launched')->value,
          'field_image' => $node->get('field_image')->entity->getFileUri(),
          'field_rate' => $node->get('field_rate')->value,
          'field_rating' => $node->get('field_rating')->value,
          'body' => $node->get('body')->value,
          'field_time' => $node->get('field_time')->value,
        ];
      }
    }

    // Return the JSON response.
    return new JsonResponse($response_data);
  }

  /**
   * Returns a JSON response with multiple images based on the slug field value from query params.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The current request object.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   The JSON response with image data or error message.
   */
public function images(Request $request) {
  $slug = $request->query->get('slug');

  if (empty($slug)) {
    $response = [
      'data' => [],
      'status' => 400,
      'messageCode' => 'SLUG_NOT_PROVIDED',
    ];
    return new JsonResponse($response, 400);
  }

  $query = \Drupal::entityQuery('node')
    ->condition('type', 'banner')
    ->condition('field_slug', $slug)
    ->accessCheck(FALSE);
  $nids = $query->execute();

  if (empty($nids)) {
    $response = [
      'data' => [],
      'status' => 404,
      'messageCode' => 'NOT_FOUND',
    ];
    return new JsonResponse($response, 404);
  }

  $node = Node::load(reset($nids));
  $images = $node->get('field_banner_image')->getValue(); // Get the field values directly

  if (!empty($images)) {
    $image_data = [];
    $file_url_generator = \Drupal::service('file_url_generator');

    foreach ($images as $image_item) {
      $file = \Drupal\file\Entity\File::load($image_item['target_id']);
      if ($file) {
        $uri = $file->getFileUri();
        $alt = isset($image_item['alt']) ? $image_item['alt'] : ''; // Get the alt text

        $image_data[] = [
          'url' => $file_url_generator->generateAbsoluteString($uri),
          'alt' => $alt,
        ];
      }
    }

    $response = [
      'data' => [
        'images' => $image_data,
      ],
      'status' => 200,
      'messageCode' => 'SUCCESS',
    ];
    return new JsonResponse($response, 200);
  }

  $response = [
    'data' => [],
    'status' => 404,
    'messageCode' => 'IMAGE_NOT_FOUND',
  ];
  return new JsonResponse($response, 404);
}


}
