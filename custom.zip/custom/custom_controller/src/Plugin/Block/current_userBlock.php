<?php

namespace Drupal\custom_controller\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\user\Entity\User;
use Drupal\Core\StreamWrapper\StreamWrapperManager;
use Drupal\Core\Url;


/**
 * Provides a 'Hello' Block.
 *
 * @Block(
 *   id = "current_userBlock",
 *   admin_label = @Translation("current user profile"),
 *   category = @Translation("custom block"),
 * )
 */
class current_userBlock extends BlockBase {
    /**
     * {@inheritdoc}
     */
    public function build() {
        
        $current_user_id = \Drupal::currentUser()->id();
        $user = User::load($current_user_id);
    
        // Get the username and user picture
        $username = $user->getDisplayName();
        $user_picture = $user->get('user_picture')->entity;
    
        // Default picture URL if no picture is found
        $picture_url = '/themes/custom/acediva/images/default-user-icon.png';
        if ($user_picture) {
            // $file_uri = $user_picture->getFileUri();
            $picture_url = \Drupal::service('file_url_generator')->generateAbsoluteString($user_picture->getFileUri());
        }


        $roles = $user->get('roles')->target_id ?? '';
        
        if ($roles == 'vendor') {
            $Profileurl = Url::fromUri('internal:/user/vendordashboard')->toString();
        } else {
            $Profileurl = Url::fromUri('internal:/user/profiledashboard')->toString();
        }
    
        // return [
        //     '#markup' => '<div class="user-detail"><div class="user-profile"><img src="'.$picture_url.'"></div>',
        // ];

        return [
            '#markup' => $this->t('<div id="header-user-detail"><div class="user-profile"><a href="'. $Profileurl .'"><img src="@picture" alt="@username" /></a></div></div>', [
                '@picture' => $picture_url,
                '@username' => $username,
            ]),
            '#cache' => [
                'max-age' => 0, // Prevent caching
            ],
        ];
    }
}