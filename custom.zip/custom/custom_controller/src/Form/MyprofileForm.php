<?php

    namespace Drupal\custom_controller\Form;

    use Drupal\Core\Form\FormBase;
    use Drupal\Core\Form\FormStateInterface;
    use Drupal\Core\Messenger\MessengerInterface;
    use Drupal\file\Entity\File;
    use Drupal\user\Entity\User;


    class MyprofileForm extends FormBase {

        /**
         * {@inheritdoc}
         */
        public function getFormId(){
            return 'my_profile_form';
        }

        /**
         * {@inheritdoc}
         */
        public function buildForm(array $form, FormStateInterface $form_state){
            $current_user_id = \Drupal::currentUser()->id();
            $user = User::load($current_user_id);

            if (empty($current_user_id)){
                // Get the redirect path.
                $redirect_path = '/user/login'; // Replace with the desired redirect path.

                $url = \Drupal\Core\Url::fromUserInput($redirect_path);
                $response = new \Symfony\Component\HttpFoundation\RedirectResponse($url->toString());
                $response->send();
                exit();
            }

            // dump($user);

            $address_field = $user->get('field_address')->getValue();
            $country_code = $administrative_area = $locality = $postal_code = $address_line1 = $address_line2 = $given_name = $family_name = '';
            if (!empty($address_field)) {
                $address_data = $address_field[0]; // Assuming you are interested in the first item.
              
                $country_code = $address_data['country_code'];
                $administrative_area = $address_data['administrative_area'];
                $locality = $address_data['locality'];
                $postal_code = $address_data['postal_code'];
                $address_line1 = $address_data['address_line1'];
                $address_line2 = $address_data['address_line2'];
                $given_name = $address_data['given_name'];
                $family_name = $address_data['family_name'];
            }

            $form['user_id'] = [
                '#type' => 'hidden',
                '#value' => $current_user_id
            ];

            $form['user_advanced'] = array(
                '#type' => 'fieldset',
                '#collapsible' => TRUE,
                '#collapsed' => FALSE,
            );

            $pictureUrl = '/themes/custom/acediva/images/default-user-icon.png';
            $pictureEntity = $user->get('user_picture')->entity;
            if ($pictureEntity){
                $pictureUrl = \Drupal::service('file_url_generator')->generateAbsoluteString($pictureEntity->getFileUri());
            }
            $form['user_advanced']['user-picture']['container']['left']['current-logo'] = [
                '#type' => 'markup',
                '#markup' => '<div class="profile-img"><div class="profile-img-title">' . $this->t('Profile Picture') . '</div><div class="logo-wrapper"><img class="current-logo" alt="" src="'.$pictureUrl.'" /></div></div>',
            ];


            $form['user_advanced']['user-picture']['container']['center']['upload-logo'] = [
                '#type' => 'managed_file',
                // '#title' => $this->t('Upload logo'),
                '#upload_location' => 'public://',
                '#upload_validators' => [
                'file_validate_extensions' => ['jpg jpeg png gif'],
                ],
                '#theme' => 'image_widget',
                '#preview_image_style' => 'medium',
                // '#description' => $this->t('Allowed extensions: jpg, jpeg, png, gif.'),
            ];

            $country_name = [
                '0' => $this->t('Select'),
                'IN' => $this->t('India')
            ];

            $form['user_advanced']['country_code_name'] = [
                '#type' => 'select',
                '#title' => $this->t('Country'),
                '#options' => $country_name,
                '#default_value' => $country_code,
                '#attributes' => [
                    'style' => ['display:none;'],  // This hides the element visually
                ],
            ];

            $form['user_advanced']['first_name'] = [
                '#type' => 'textfield',
                '#title' => $this->t('First name'),
                '#default_value' => $given_name,
                '#required' => TRUE,
            ];

            $form['user_advanced']['last_name'] = [
                '#type' => 'textfield',
                '#title' => $this->t('Last name'),
                '#default_value' => $family_name,
                '#required' => TRUE,
            ];

            $form['user_advanced']['email_address'] = [
                '#type' => 'email',
                '#title' => $this->t('Email address'),
                '#default_value' => $user->get("mail")->value,
                '#disabled' => TRUE
            ];

            $form['user_advanced']['street_address1'] = [
                '#type' => 'textfield',
                // '#title' => $this->t('Street address'),
                '#default_value' => $address_line1,
                // '#required' => TRUE,
                '#attributes' => [
                    'style' => ['display:none;'],  // This hides the element visually
                ],
            ];

            $form['user_advanced']['street_address2'] = [
                '#type' => 'textfield',
                '#default_value' => $address_line2,
                '#attributes' => [
                    'style' => ['display:none;'],  // This hides the element visually
                ],
            ];

            $form['user_advanced']['city_select'] = [
                '#type' => 'select',
                // '#title' => t('Select your city'),
                '#options' => [
                  'delhi' => t('Delhi'),
                  'noida' => t('Noida'),
                  'greater_noida' => t('Greater Noida'),
                ],
                '#default_value' => $locality,
                '#attributes' => [
                    'style' => ['display:none;'],  // This hides the element visually
                ],
            ];

            $form['user_advanced']['city'] = [
                '#type' => 'textfield',
                '#title' => $this->t('City'),
                '#default_value' => $locality,
                // '#required' => TRUE,
                '#attributes' => [
                    'style' => ['display:none;'],  // This hides the element visually
                ],
            ];

            $form['user_advanced']['postal_code'] = [
                '#type' => 'textfield',
                // '#title' => $this->t('Pin code'),
                '#default_value' => $postal_code,
                // '#required' => TRUE,
                '#attributes' => [
                    'style' => ['display:none;'],  // This hides the element visually
                ],
            ];

            $indian_states = [
                '0' => '- Select -',
                'AN' => 'Andaman & Nicobar',
                'AP' => 'Andhra Pradesh',
                'AR' => 'Arunachal Pradesh',
                'AS' => 'Assam',
                'BR' => 'Bihar',
                'CH' => 'Chandigarh',
                'CG' => 'Chhattisgarh',
                'DH' => 'Dadra & Nagar Haveli & Daman & Diu',
                'DL' => 'Delhi',
                'GA' => 'Goa',
                'GJ' => 'Gujarat',
                'HR' => 'Haryana',
                'HP' => 'Himachal Pradesh',
                'JK' => 'Jammu & Kashmir',
                'JH' => 'Jharkhand',
                'KA' => 'Karnataka',
                'KL' => 'Kerala',
                'LA' => 'Ladakh',
                'LD' => 'Lakshadweep',
                'MP' => 'Madhya Pradesh',
                'MH' => 'Maharashtra',
                'MN' => 'Manipur',
                'ML' => 'Meghalaya',
                'MZ' => 'Mizoram',
                'NL' => 'Nagaland',
                'OD' => 'Odisha',
                'PY' => 'Puducherry',
                'PB' => 'Punjab',
                'RJ' => 'Rajasthan',
                'SK' => 'Sikkim',
                'TN' => 'Tamil Nadu',
                'TS' => 'Telangana',
                'TR' => 'Tripura',
                'UP' => 'Uttar Pradesh',
                'UK' => 'Uttarakhand',
                'WB' => 'West Bengal',
            ];

            $form['user_advanced']['state'] = [
                '#type' => 'select',
                '#title' => $this->t('State'),
                '#options' => $indian_states,
                '#default_value' => $administrative_area,
                // '#required' => TRUE,
                '#attributes' => [
                    'style' => ['display:none;'],  // This hides the element visually
                ],
            ];

            $form['user_advanced']['reset_password_button'] = [
                '#type' => 'markup',
                '#markup' => '<div class="reset-password-button-wrapper"><span id="reset-password-button">Reset Password</span></div>',
            ];

            $form['user_advanced']['current_password_container'] = [
                '#type' => 'container'
            ];

            $form['user_advanced']['current_password_container']['current_password'] = [
                '#type' => 'password',
                '#title' => $this->t('Current password'),
                '#default_value' => '',
                '#required' => FALSE,
                // '#description' => 'Required if you want to change the email address or Password below. Reset your password',
                '#ajax' => [
                    'event' => 'change',
                    'callback' => '::checkCurrentPassword',
                    'wrapper' => 'current-password-check-message'
                ],
                '#prefix' => '<div id="current-password">',
                '#suffix' => '</div>'
            ];

            $form['user_advanced']['current_password_container']['current_password_check_message']=[
                '#type' => 'markup',
                '#markup' => '',
                '#prefix' => '<div id="current-password-check-message">',
                '#suffix' => '</div>'
            ];

            
            $form['user_advanced']['password_container'] = [
                '#type' => 'container'
            ];
            $form['user_advanced']['password_container']['password'] = [
                '#type' => 'password',
                '#title' => $this->t('New Password'),
                '#default_value' => '',
                        ];
            $form['user_advanced']['password_container']['confirm_password'] = [
                '#type' => 'password',
                '#title' => $this->t('Confirm Password'),
                '#default_value' => '',
                '#ajax' => [
                    'event' => 'change',
                    'callback' => '::checkPasswords',
                    'wrapper' => 'password-mismatch-error'
                ]
                        ];   
                        
            $form['user_advanced']['password_container']['password_mismatch_error'] = [
                '#type' => '#markup',
                '#markup' => '',
                '#prefix' => '<div id="password-mismatch-error">',
                '#suffix' => '</div>'
            ];

            $form['user_advanced']['submit'] = [
                '#type' => 'submit',
                '#value' => $this->t('Update'),
                '#attributes' => [
                    'class' => ['update-profile-button'],
                ],
            ];
        
            return $form; 

        }

        public function checkCurrentPassword(array &$form, FormStateInterface $form_state){
            $inputted_current_password = $form_state->getValue('current_password');
           
            $current_user_id = \Drupal::currentUser()->id();
            $current_user = User::load($current_user_id);
            $current_password= $current_user->get('pass')->value;
            $password_check = password_verify($inputted_current_password,$current_password);
            if(empty($current_password)){
                $form['user_advanced']['current_password_container']['current_password_check_message']['#markup'] = ''; 
                return $form['user_advanced']['current_password_container']['current_password_check_message'];
            }
            else{
                if(!$password_check){
                    $form['user_advanced']['current_password_container']['current_password_check_message']['#markup'] = '<p class="error">Incorrect current password</p>';
                    return $form['user_advanced']['current_password_container']['current_password_check_message'];
                }
                else{
                    $form['user_advanced']['current_password_container']['current_password_check_message']['#markup'] = '';
                    return $form['user_advanced']['current_password_container']['current_password_check_message'];
                }
            }
        
        }

        public function checkPasswords(array &$form, FormStateInterface $form_state){
            $password = $form_state->getValue('password');
            $confirm_password = $form_state->getValue('confirm_password');

            // Validate if the passwords match
            if (empty($confirm_password)) {
                $form['user_advanced']['password_container']['password_mismatch_error']['#markup'] = '<p class="warning">Confirm password is required field</p>';
            }
            else if ($password !== $confirm_password){
                $form['user_advanced']['password_container']['password_mismatch_error']['#markup'] = '<p class="error">The password and confirmation password do not match.</p>';
            }
            else{
                $form['user_advanced']['password_container']['password_mismatch_error']['#markup'] = '';
            }
            return $form['user_advanced']['password_container']['password_mismatch_error'];
        }

        public function submitForm(array &$form, FormStateInterface $form_state){

            $country_code_name = $form_state->getValue('country_code_name');
            $first_name=$form_state->getValue('first_name');
            $last_name=$form_state->getValue('last_name');
            $street_address1=$form_state->getValue('street_address1');
            $street_address2 = $form_state->getValue('street_address2');
            $city = $form_state->getValue('city_select');
            $postal_code = $form_state->getValue('postal_code');
            $state = $form_state->getValue('state');
            $upload_pic = $form_state->getValue('upload-logo');
            $user_id = $form_state->getValue('user_id');

            // Load user entity
            $user = User::load($user_id);
            
            $user->set('field_address', [
                'country_code' => $country_code_name,
                'given_name' => $first_name,
                'family_name' => $last_name,
                'address_line1' => $street_address1,
                'address_line2' => $street_address2,
                'locality' => $city,
                'administrative_area' => $state,
                'postal_code' => $postal_code,
            ]);

            // Update user picture if uploaded
            if (!empty($upload_pic)) {
                $file_entity = File::load($upload_pic[0]);
                $user->set('user_picture', $file_entity);
            }

            // Handle password change
            $inputted_current_password = $form_state->getValue('current_password');
            if (isset($inputted_current_password) && !empty($inputted_current_password)) {
                $current_password = $user->get('pass')->value;

                // Verify current password
                $password_check = password_verify($inputted_current_password, $current_password);
                if ($password_check) {
                    $password = $form_state->getValue('password');
                    $confirm_password = $form_state->getValue('confirm_password');
                    if ($password == $confirm_password) {
                        // Update password if new passwords match
                        $user->setPassword($password);
                    } else {
                        \Drupal::messenger()->addError("New passwords do not match, try again.");
                        return;
                    }
                } else {
                    \Drupal::messenger()->addError("Current password doesn't match, try again.");
                    return;
                }
            }

            $save = $user->save();
            if ($save) {
                \Drupal::messenger()->addMessage(t('Updated successfully'));
            } else {
                \Drupal::messenger()->addMessage(t('Update failed'));
            }

        }
    }