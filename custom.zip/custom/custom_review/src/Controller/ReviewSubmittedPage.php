<?php

namespace Drupal\custom_review\Controller;

use Drupal\Core\Controller\ControllerBase;

class ReviewSubmittedPage extends ControllerBase {

    public function reviewSubmittedMessage() {
        return [
            '#markup' => '<div class="alert alert-success" role="alert"><p>Thank you for your review! We appreciate your feedback</p><a href="https://dev-acediva.pantheonsite.io/">Acediva</a></div>',
        ];
    }
}
