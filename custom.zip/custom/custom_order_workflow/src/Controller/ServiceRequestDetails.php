<?php

namespace Drupal\custom_order_workflow\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\commerce_order\Entity\OrderInterface;
use Drupal\commerce_order\Entity\Order;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\commerce_price\Price;
use Drupal\user\Entity\User;

class ServiceRequestDetails extends ControllerBase
{
    /**
     * Displays order details.
     *
     * @param int $order_id
     *   The order ID.
     *
     * @return array
     *   A render array.
     */

    public function showDetails($order_id = NULL)
    {
        $return_array = [];
        $order = Order::load($order_id);
        $vendor_uid = $order->get('field_vendor_uid')->value ?? '';
        $currentUserId = \Drupal::currentUser()->id();

        if ($order && $vendor_uid == $currentUserId) {

            $order_state = $order->get('state')->value;
            

            if($order_state == 'service'){

                $order_status = 'Pending';
                // Time Slot
                $time_slot_target_id = $order->get('field_select_time_slot')->target_id ?? '';
                if ($time_slot_target_id) {
                    $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($time_slot_target_id);
                    if ($term) {
                        $time_slot_name = $term->getName();
                    }
                }

                // Order-items
                $items = $order->getItems();
                $order_items = [];
                foreach ($items as $item) {
                    // Get the product variation (if needed).
                    $product_variation = $item->getPurchasedEntity();
                    // Get the title, quantity, and price.
                    $order_items[] = [
                        'title' => $product_variation->getTitle(), // Get the product title.
                        'quantity' => $item->getQuantity(), // Get the quantity.
                        'price' => $item->getTotalPrice(), // Get the subtotal price.
                    ];
                    // $order_items[] = $item;
                }

                // Function to replace all null value to empty string
                function convertNullsToEmptyStrings($array){
                    foreach ($array as $key => $value) {
                        if (is_null($value)) {
                            $array[$key] = ''; 
                        } elseif (is_array($value)) {
                            $array[$key] = convertNullsToEmptyStrings($value);
                        }
                    }
                    return $array;
                }

                // Payment Summary

                $total_price = $order->getTotalPrice();
                $total_paid = $order->getTotalPaid();
                $total_dues = $order->getTotalPrice()->getNumber() - $order->getTotalPaid()->getNumber();
                $payment_status =  '';
                if ($total_dues > 0) {
                    $payment_status = 'due';
                } else {
                    $payment_status = 'paid';
                }
                // Service Address
                if($order->getBillingProfile()){
                    $billing_address = $order->getBillingProfile()->get('address')->first()->getValue();
                    $customer_mobile = $order->getBillingProfile()->get('field_mobile')->first()->getValue();
                    if ($billing_address['country_code'] == 'IN') {
                        $billing_address['country_code'] = 'India';
                    }
                }

                $order_data = [ 
                    'order_id' => $order_id,
                    'placed_date' => DrupalDateTime::createFromTimestamp($order->getCreatedTime())->format('d-M-Y'),
                    'state' => $order_state,
                    'status' => $order_status,
                    'service_date' => $order->get('field_select_date')->value,
                    'service_time' => $time_slot_name,
                    'order_items' => $order_items,
                    'total_price' => $total_price,
                    'total_paid' => $total_paid,
                    'total_dues' => $total_dues,
                    'payment_status' => $payment_status,
                    'billing_address' => convertNullsToEmptyStrings($billing_address),
                    'customer_mobile' => $customer_mobile['value'],
                ];

                return [
                    '#theme' => 'service_request_details',
                    '#order' => $order_data, // Pass an array with scalar values.
                    '#cache' => [
                        'max-age' => 0, // Disable caching for demonstration.
                    ],
                ];

            }elseif($order_state == 'completed') {
                $return_array = [
                    '#markup' => $this->t('<div class="alert alert-success" role="alert"><h4>Service Completed</h4><hr><p>Service has been completed.</p></div>'),
                    '#cache' => [
                        'max-age' => 0,
                    ],
                ];
            }elseif($order_state == 'draft'){
                $return_array = [
                    '#markup' => $this->t('<div class="alert alert-warning" role="alert"><h4>Order Not Placed Yet!</h4><hr><p>Order has not been placed by the user</p></div>'),
                    '#cache' => [
                        'max-age' => 0,
                    ],
                ];
            }elseif($order_state == 'cancel'){
                $return_array = [
                    '#markup' => $this->t('<div class="alert alert-danger" role="alert"><h4>Order Cancelled</h4><hr><p>Service has been cancelled</p></div>'),
                    '#cache' => [
                        'max-age' => 0,
                    ],
                ];
            }else{
                $return_array = [
                    '#markup' => $this->t('<div class="alert alert-danger" role="alert"><h4>Order Not Found</h4><hr><p>The requested order does not found. Please check the order id</p></div>'),
                    '#cache' => [
                        'max-age' => 0,
                    ],
                ];
            }
            
        }else{
            $return_array = [
                '#markup' => $this->t('<div class="alert alert-danger" role="alert"><h4>Order Not Found</h4><hr><p>The requested order does not found or order does not assigned to you. Please check the order id</p></div>'),
                '#cache' => [
                    'max-age' => 0,
                ],
            ];
        }

        return $return_array;
    }
}
