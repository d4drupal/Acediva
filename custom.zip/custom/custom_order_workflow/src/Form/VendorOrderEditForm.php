<?php

namespace Drupal\custom_order_workflow\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\commerce_order\Entity\Order;
use Drupal\user\Entity\User;

class VendorOrderEditForm extends FormBase{
    /**
     * {@inheritdoc}
     */
    public function getFormId(){
        return 'vendor_order_edit_form';
    }

    public function buildForm(array $form, FormStateInterface $form_state, $order_id = NULL){
        
        $order = Order::load($order_id);

        if (!$order) {
            return [
                '#markup' => '<div class="alert alert-danger" role="alert">Order Not Found</div>',
            ];
        }

        $current_order_state = $order->get('state')->value;
        $vendor_uid = $order->get('field_vendor_uid')->value ?? '';
        $currentUserId = \Drupal::currentUser()->id();

        if($current_order_state == 'cancel'){
            $order_status = 'Cancelled';
        }elseif($current_order_state == 'service'){
            $order_status = 'Pending';
        }elseif($current_order_state == 'completed'){
            $order_status = 'Completed';
        }
        
        // Check if vendor id is current user id
        if($currentUserId == $vendor_uid){

            $form['form_header'] = [
                '#markup' => '<h1 class="form-header">Update Service Status</h1>',
            ];

            $form['order_description'] = [
                '#markup' => '<div class="order-description">
                                <div>
                                    <div>Order ID : #'.$order_id.'</div>
                                </div>
                                <div>Status : '.$order_status.'</div>
                            </div>',
            ];

            if($current_order_state == 'service'){
                $form['order_id'] = [
                    '#type' => 'hidden',
                    '#value' => $order_id,
                ];
                $form['new_order_state'] = [
                    '#type' => 'radios',
                    '#options' => [
                        'service' => 'Complete Service',
                        'cancel' => 'Cancel Service',
                    ],
                    '#required' => TRUE,
                    '#attributes' => ['class' => ['new-order-state']],
                ];
                $form['service_complete_options'] = [
                    '#type' => 'container',
                    '#attributes' => ['class' => ['service-complete-options-container']],
                ];
                $form['service_complete_options']['payment_received'] = [
                    '#type' => 'checkbox',
                    '#title' => $this->t('Received the payment'),
                ];
                $form['service_complete_options']['work_status'] = [
                    '#type' => 'checkbox',
                    '#title' => $this->t('Completed all the procedures'),
                ];
                $form['service_cancel_options'] = [
                    '#type' => 'container',
                    '#attributes' => ['class' => ['service-cancel-options-container']],
                ];
                $form['service_cancel_options']['confirm_cancel'] = [
                    '#type' => 'checkbox',
                    '#title' => $this->t('Are you sure to cancel the service'),
                ];
                $form['actions']['#type'] = 'actions';
                $form['actions']['submit'] = [
                    '#type' => 'submit',
                    '#value' => $this->t('Update Order Status'),
                ];
            }elseif($current_order_state == 'completed'){
                $form['order_completed'] = [
                    '#markup' => '<div class="alert alert-success" role="alert">Service Already Completed</div>',
                ];
            }elseif($current_order_state == 'cancel'){
                $form['order_completed'] = [
                    '#markup' => '<div class="alert alert-danger" role="alert">Service Already Cancelled</div>',
                ];
            }
        }else{
            $form['order_completed'] = [
                '#markup' => '<div class="alert alert-danger" role="alert">You are not authorized to edit this order</div>',
            ];
        }        

        return $form;
    }

    public function validateForm(array &$form, FormStateInterface $form_state){
        if (empty($form_state->getValue('new_order_state'))) {
            $form_state->setErrorByName('new_order_state', t('Please select an option'));
        }
    }

    /**
     * Form submission handler.
     */
    public function submitForm(array &$form, FormStateInterface $form_state){
        
        $order_id = $form_state->getValue('order_id');
        $order = Order::load($order_id);

        // Update the order state.
        $new_state = $form_state->getValue('new_order_state');
        $order_state = $order->getState();
        $order_state_transitions = $order_state->getTransitions();
        $order_state->applyTransition($order_state_transitions[$new_state]);
        $order->save();

        $form_state->setRedirectUrl(\Drupal\Core\Url::fromUri('internal:/service-request-details/' . $order_id));
    }
}
